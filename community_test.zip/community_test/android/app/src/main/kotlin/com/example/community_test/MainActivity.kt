package com.example.community_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
